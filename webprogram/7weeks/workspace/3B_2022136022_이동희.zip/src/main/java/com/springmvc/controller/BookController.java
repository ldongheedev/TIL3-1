package com.springmvc.controller;


import java.util.List;
import java.util.Map;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.MatrixVariable;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.springmvc.domain.Book;
import com.springmvc.service.BookService;


@Controller
@RequestMapping(value = "/books")
public class BookController {
	@Autowired
	private BookService bookService;
	
	
	@GetMapping
	public String requestBookList (Model model) {
		List<Book> list = this.bookService.getAllBookList();
		model.addAttribute("bookList", list);
		
			
		return "books";
	}
	
	@GetMapping("/all")
	public ModelAndView requestAllBooks() {
		List<Book> list = this.bookService.getAllBookList();
		
		ModelAndView mav = new ModelAndView();
		mav.addObject("bookList", list);
		mav.setViewName("books");
		
		return mav;
	}
	

	@GetMapping("/{category}")
	public String requestBooksByCategory(@PathVariable("category") String bookCategory, Model model) {
		List<Book> booksByCategory = this.bookService.getBookListByCategory(bookCategory);
		model.addAttribute("bookList", booksByCategory);
		
		return "books";
	}
	
	@GetMapping("/filter/{bookFilter}")
	public String requesBookByFilter(@MatrixVariable(pathVar="bookFilter")
	Map<String, List<String>> bookFilter, Model model) {
		Set<Book> booksByFilter = this.bookService.getBookListByFilter(bookFilter);
		model.addAttribute("bookList", booksByFilter);
		
		return "books";
	}
}


